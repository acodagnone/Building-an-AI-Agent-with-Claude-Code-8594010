# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 4.1 — Close the Agent loop

### Prompt 1: Write the search-wiring test

```
Per PRD §16.3, the §16.1 bullet tagged **(search wiring)** — "the agent invokes `searchWeb` at least once during `researchCompany`, verified via `steps.length > 1` and tool-call inspection" — is the spec test for this change.

Add it to `tests/research.test.ts`. The (search wiring) suite additionally skips when `TAVILY_API_KEY` is unset (per §16.1) — wire that env skip alongside the existing `ANTHROPIC_API_KEY` skip from (researchCompany seed).

Test execution contract: §16.2. Real Tavily + Anthropic, no mocks.

Stop after the test is in place and confirm red by running `/tdd`. Do not wire `searchWeb` into `researchCompany` yet.
```

### Prompt 2: Wire searchWeb into the loop

```
Wire `searchWeb` into `researchCompany` to make the failing test green. Do not modify the test.

Import `searchWeb` from `src/tools/tavily.ts`, pass it in the `tools` map to `generateText`, and set `stopWhen: stepCountIs(5)` (per §4.2 — `stopWhen` with `stepCountIs`, not the v4 `maxSteps`). Five steps gives the Brain room for a few searches plus reasoning.

Run `/tdd` until green.
```

### Prompt 3: Run and stream the loop

```
Run researchCompany on "Shopify" and stream what's happening.
```
