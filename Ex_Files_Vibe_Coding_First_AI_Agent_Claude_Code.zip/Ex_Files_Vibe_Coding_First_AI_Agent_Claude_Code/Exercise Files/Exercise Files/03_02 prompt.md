# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 3.2 — Write the system prompt

### Prompt 1: Create brain.md and wire it in

```
Create the system prompt for the research agent at `src/agent/prompts/brain.md`. Pull persona, signals, honesty rule, and scoring rubric from PRD §1, §1.1, §7.3, §8, §9.

Scope: this version is pre-memory. Do not reference `listPreferences`, `addPreference`, or `removePreference`. `searchWeb` is available — reference it as needed.

Adapt and condense the PRD — don't restate it verbatim. ONE exception: the four-bullet product description in §1.1 must appear word-for-word per §1.1's canonical-language rule.

Required structure:

1. **Role + how the agent scores** — anchor on the §1.1 vendor description verbatim, including all four product modalities. "Fit-for-us" means the prospect plausibly has pain that one of those four capabilities addresses — not impressive growth in the abstract.

2. **What the agent does** — search the web for evidence, score for support-fit, produce the analysis, stop. Suggest query dimensions that tend to surface real signal as *examples*, not a quota:

   - `<company> hiring` — CX leadership, multilingual roles
   - `<company> product launch` — new lines, geographies, SKUs
   - `<company> partnership` — named partners, integrations
   - `<company> funding` / `<company> acquisition`

   Note that a bare-name query pulls SEO listicles; focused queries do better. Do not prescribe a search count — let the agent decide.

3. **Scope of the job** — per the loop boundary in §12.1, the agent does NOT write to Airtable directly, does NOT draft outreach, does NOT promise follow-up. Structuring and the Airtable upsert run outside the loop in code. The job ends with the analysis.

4. **Output format** — narrate in plain text first, then a structured analysis in markdown: `## {Company}`, `### Overview`, `### Buying signals` (each rendered `- **<name> (<strength>):** <description>`, strength ∈ strong/moderate/weak), `### Lead score: N`, `### Reasoning`, `### Suggested angle`. Prose, not JSON.

5. **Honesty rule** per §7.3. Concrete failure rule: if multiple focused queries return no substantive evidence, produce `Lead score: 1`, one weak signal labelled `Insufficient data`, and reasoning that says `"not found"`.

6. **Three worked examples using fictional company names**, placed before the rubric:

   (i) strong fit — signals match support pain;
   (ii) strong company, signals don't tie to support pain — teaches fit-for-us by absence, not category;
   (iii) insufficient data — multiple focused queries returning only directory listings, ending with `### Lead score: 1` per rule 5.

7. **Reference material at the end** — the scoring rubric from §8, an expanded buying-signals table translating §9's categories into support-specific examples with a "why it matters to us" column tied to §1.1's four modalities, and the anti-spam rule from §9.

Update `researchCompany` to load this file at runtime as the system prompt (`fs.readFileSync` per §1.2).
```

### Prompt 2: Re-run on the same company to see the prompt take effect

```
Research Shopify — show me the raw response, don't summarize it.
```
