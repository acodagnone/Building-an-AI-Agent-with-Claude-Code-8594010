# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 6.2 — Draft the outreach email

### Prompt 1: Create the outreach system prompt

```
Create the system prompt for outreach drafting at `src/agent/prompts/outreach.md`. Spec: PRD §1.1 (canonical product description, verbatim) and §11.4 (the seven required contents — land all seven). §11.1's schema is enforced by `generateObject` per §12.4, so do not duplicate the JSON shape inside the prompt. Behavioral rules come from §11.4 rule 2 (the prompt-enforceable subset of §11.2), not raw §11.2.
```

### Prompt 2: Write the draftOutreach tests

```
Write tests for `draftOutreach(domain)` at `tests/outreach.test.ts`. Tests only — do not implement `src/agent/outreach.ts` yet.

- Test spec: PRD §16.1 'Outreach drafting — draftOutreach' — only bullets tagged (outreach drafting). If any bullet asserts on integration with code from a later stage, skip it and surface.

- Behavior spec: §11.1 (schema), §11.2 (rules), §15 (errors).

- Test execution contract: §16.2 — env loading, observable skips, and the missing-env test in its own top-level `describe('Outreach — missing env (always runs)', ...)` block (so it does not silently pass by being skipped).

- Airtable conventions: §12.3 — verifier ≠ cleaner. Use the read primitives `getProspectIdByDomain` and `listOutreachByProspectId` to assert persistence; never use `deleteOutreachByProspect`'s return count as the assertion (a function under test can't validate itself). Cleanup order: `deleteOutreachByProspect` before `deleteProspectByDomain`.

One real `draftOutreach` call per run — call it once in `beforeAll`, share the result across all assertion blocks. Only the unknown-company error test calls `draftOutreach` itself.

Two deterministic domains:

- `outreachtestco` — seeded in `beforeAll`, torn down in `afterAll`. Seed match tokens per §16.1: paraphrase-resistant (specific numerals or proper nouns), placed only inside `signals[].description`, never in `suggestedAngle` / `scoreReasoning` / `overview` / `companyName`.

- `outreachunknownco` — never seeded; used for the `Research <Company> first.` error path.

Before writing tests, ensure listOutreachByProspectId and deleteOutreachByProspect exist in src/tools/airtable.ts. If missing, add them per §12.3 conventions (exact names). Then write the tests.

Use Airtable helper names exactly as written in §12.3. If any helper is missing from `src/tools/airtable.ts` by that exact name, stop and surface — PRD wins on names.
```

### Prompt 3: Implement draftOutreach

```
Implement `draftOutreach(domain)` in `src/agent/outreach.ts`.

Spec: PRD §11.1 (schema), §11.2 (rules), §11.3 (persistence), §11.4 (system prompt), §12.3 (Airtable helpers), §12.4 (tool surface), §15 (errors). The tests in `tests/outreach.test.ts` are the spec — implement red → green.

Steps, in this order (§11.2 fixes the order; the tests enforce it):

1. **API key check.** If `ANTHROPIC_API_KEY` is missing or empty, throw an error mentioning `ANTHROPIC_API_KEY`. This runs before Airtable lookup, before prompt load, before any model call.

2. **Prospect lookup** via `getProspectByDomain(client, domain)` from `src/tools/airtable.ts` (§12.3). On no-match, throw `Research ${companyName ?? domain} first.` per §15. Reuse the returned record id for step 6.

3. **Read preferences** at `src/memory/preferences.md` directly with `readFileSync` — drafting reads memory in code, not via the `listPreferences` tool (§12.4). Treat a missing file as an empty string; do not throw (§10).

4. **Load the system prompt** at `src/agent/prompts/outreach.md` with `readFileSync`. Drafting rules live in the prompt file, not in code (§11.4).

5. **Call `generateObject`** with `OutreachSchema`. The only context is the prospect data and the preferences string. No tools, no agent loop (§12.4). Validate the result against the schema before moving on.

6. **Persist** via `createOutreach(client, prospectId, outreach)` from `src/tools/airtable.ts` (§11.3, §12.3). Reuse the record id from step 2. If `createOutreach` doesn't exist yet, add it following §12.3 conventions (exact-name tool lookup, `list_tables_for_base` field-id map, `typecast: true`, linked-record value as `[prospectId]`). Do not inline the Airtable `create_records_for_table` call in `outreach.ts`. Then return the parsed `OutreachSchema` object.

*Export both `draftOutreach` and `OutreachSchema` — the tests import both.*

Use helper names exactly as written. If any Airtable helper name in §12.3 doesn't exist in `airtable.ts` by that exact name, stop and surface. Don't substitute a similar name (singular vs plural, etc.). PRD wins on names (CLAUDE.md global rule).

Run /tdd until green and tests are passing.
```

### Prompt 4: Draft outreach for a researched prospect

```
Draft outreach for Shopify.
```

### Prompt 5: Draft outreach for a company not yet researched

```
Draft outreach for DHL.
```
