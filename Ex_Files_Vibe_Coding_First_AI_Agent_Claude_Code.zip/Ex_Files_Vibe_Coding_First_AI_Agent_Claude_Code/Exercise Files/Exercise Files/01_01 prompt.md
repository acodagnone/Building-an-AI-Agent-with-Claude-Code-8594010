# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 1.1 — Set up the project and plan the build

### Prompt 1: Scaffold the project

```
Set up the TypeScript project to match PRD §1.2 (repo layout), §4.2 (dependencies and pin discipline), and §4.3 (tsconfig). Initialize the package and install dependencies at exactly the versions pinned in §4.2 — do not let npm install default to latest of anything. Create empty placeholder files for every file path listed in §1.2's repo-layout tree, including all nested files: src/agent/research.ts, src/agent/outreach.ts, src/agent/prompts/brain.md, src/agent/prompts/outreach.md, src/tools/tavily.ts, src/tools/airtable.ts, src/memory/preferences.ts. Do not skip nested files. Create the tests/ directory itself (e.g., with a .gitkeep file so it's tracked), but do not create any .test.ts files inside it — that folder stays empty until each feature's TDD step creates its own test file. §16.1 lists the v1 end-state for tests/; treat it as a future inventory, not a scaffolding checklist.
```
