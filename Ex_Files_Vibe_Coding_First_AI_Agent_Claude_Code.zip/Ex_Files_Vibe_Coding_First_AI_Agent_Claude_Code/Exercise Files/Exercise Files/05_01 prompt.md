# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 5.1 — Build agent memory

### Prompt 1: Write the preferences tests

```
Write the test suite for the preferences memory layer at `tests/memory/preferences.test.ts`. Tests only — do not implement `src/memory/preferences.ts` yet.

- Test spec: PRD §16.1 'Preferences memory' — only bullets tagged (preferences memory). Skip any bullet that depends on researchCompany calling these tools — that integration belongs to (preferences wiring).

- Behavior spec: PRD §10 (memory model).

- Test execution contract: §16.2.

Tests hit the real `src/memory/preferences.md` file — no mocks. Each test must restore or delete the file after running so subsequent runs start clean. Use `.ts` import extensions per §1.2.

After writing the tests, confirm red by running `/tdd`. Stop there.
```

### Prompt 2: Implement the three preference tools

```
Implement `src/memory/preferences.ts` to make `tests/preferences.test.ts` green. Do not modify the tests.

Three functions, each wrapped with the Vercel AI SDK `tool()` helper and given a clear description so the Brain knows when to call it — exact behavior spec'd in PRD §10.3: `listPreferences()`, `addPreference(text)`, `removePreference(text)`. File location: `src/memory/preferences.md` per §10.2.

Use `.ts` import extensions per §1.2. Run `/tdd` until green.
```
