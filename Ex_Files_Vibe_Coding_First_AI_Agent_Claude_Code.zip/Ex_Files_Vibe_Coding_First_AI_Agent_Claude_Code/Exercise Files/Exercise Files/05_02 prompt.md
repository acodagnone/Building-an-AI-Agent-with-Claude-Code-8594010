# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 5.2 — Wire memory into the brain

### Prompt 1: Write the preference-wiring tests

```
Write the tests for the preference wire-up. Add them to `tests/research.test.ts`. Tests only — do not modify `src/agent/research.ts` or `src/agent/prompts/brain.md`.

- Test spec: PRD §16.1 'Preference-driven agent behavior' — only bullets tagged (preferences wiring). Skip any bullet asserting on result.prospect.* fields like suggestedAngle or leadScore — those depend on structureProspect from (structurer + persistence), which is built later.
The acceptance test for this stage is the bullet asserting researchCompany begins with a listPreferences tool call (verified via steps inspection). Without it, the wiring can silently regress when someone edits the tools map.
- Test execution contract: §16.2 — real-API tests inside the existing describe.skipIf(...) block alongside the existing tests; update the file's console.warn skip notice to name every env var the suite now requires.

Tests that touch `src/memory/preferences.md` must restore or delete the file afterward. Use `.ts` import extensions per §1.2. Confirm red, then stop.
```

### Prompt 2: Update brain.md with preference handling (run in parallel session)

```
Update src/agent/prompts/brain.md to add preference handling. brain.md already exists from the 3.2 step (without memory). Add the four pieces below verbatim. If any already exist, leave them alone.

1. At the top of `## What you do`, insert:

> Always start by calling `listPreferences`. Apply preferences that match the prospect's category. Cite which applied in your narrated output (e.g. *"Applying saved preference: for shipping companies, lead with multilingual deflection."*). If none apply, say so and proceed.

2. After the focused-queries paragraph in `## What you do`, insert:

> **Manage preferences only when the user asks.** If the user states a stateful preference ("for shipping always lead with X", "always include Y"), call `addPreference` and acknowledge: `Saved preference: <text>.` If the user asks to remove one, call `removePreference` and acknowledge. **Never invent a preference the user did not state — saves are explicit user requests only.**

3. Insert a new `## Preferences and scoring` section between `## Honesty rule` and the worked-examples block. Use this exact content:

## Preferences and scoring
Saved preferences modify how the rubric and the honesty rule apply on this run.

- **Signal elevation.** A preference-classified strong signal alone supports a Lead score in the 60–79 band. 80+ still requires multiple strong signals.
- **Penalty suspension.** When a preference treats an absence as expected for a category, don't penalize the score for it.
- **Honesty rule, narrowed.** "Thin sources → lower score" applies only to dimensions the preference doesn't address.
- **Angle binding.** When a preference specifies a default angle, use it in `Suggested angle`. **This overrides the honesty rule's "insufficient data" template.** Never output *"N/A — insufficient data"*, *"skip for now"*, *"wait and monitor"*, *"monitor for..."*, or *"hold off"* in `Suggested angle` for a prospect an active preference covers.

4. Two small edits:
   - In the narration paragraph (likely "Narrate your work in plain text as you go..."), insert "what preferences you read" at the start of the list.
   - In each worked example's setup line, insert "Preferences read: none applied." between the company name and the search-findings sentence.

Idempotency: if a section contains an outdated version (e.g. angle-binding rule missing some forbidden phrases), replace it wholesale with the version above.
```

### Prompt 3: Wire the three preference tools into the agent loop

```
Wire the three preference tools into the agent loop, code-side only — leave `src/agent/prompts/brain.md` alone (handled separately).

Pass `listPreferences`, `addPreference`, and `removePreference` into `researchCompany`'s `tools` map alongside `searchWeb`. Per §12.1, all four belong inside the loop — the Brain decides which preferences apply and recognizes save-worthy intent. Bump `stopWhen: stepCountIs(5)` → `stepCountIs(8)` (per §4.2's `stopWhen` API) — preferences add about 2 extra tool calls per run, and 5 cuts the loop short.

Do not edit `tests/research.test.ts`. The preference-wiring tests stay red until `brain.md` is updated to tell the agent when to call these tools.
Run /tdd and confirm green.
```

### Prompt 4: Research the first company (no preferences saved yet)

```
Research FedEx as a prospect.
```

### Prompt 5: Save a stateful preference

```
For shipping & logistics companies, treat international expansion as a strong buying signal for multilingual support — they always have multilingual support pain even when they don't post CX hiring ads. Don't downgrade the score for missing hiring signals in this vertical.
```

### Prompt 6: Research a different company in the same vertical

```
Research UPS as a prospect.
```
