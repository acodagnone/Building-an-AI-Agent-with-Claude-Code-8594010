# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 6.1 — Structure and save the results to the Airtable

### Prompt 1: Write the (structurer + persistence) tests

```
Write the tests for (structurer + persistence) at `tests/research.test.ts`. Tests only — do not modify `src/agent/research.ts` yet.

- Cover every §16.1 bullet tagged **(structurer + persistence)** under "Company research" — full `ProspectSchema` match, `leadScore` integer in [1, 100], non-empty `signals` with valid strength enums, canonical `domain` form, `Prospects`-table compatibility, the `structureProspect` `.omit` negative test, and the post-run Airtable persistence assertion (read back via `list_records_for_table` with the structured filter, values off `r.cellValuesByFieldId[fldXXX]`).
- The (researchCompany seed) bullet and (search wiring) bullet keep firing — rewire them to the new `{ prospect, steps }` return shape per §12.3. Do not re-author.
- Test execution contract: §16.2 — real-API tests inside `describe.skipIf`, missing-env in its own always-runs describe. Add the `AIRTABLE_API_KEY` / `AIRTABLE_BASE_ID` skip per §16.1's (structurer + persistence) bullet.
- Cleanup via `deleteProspectByDomain` from `src/tools/airtable.ts` per §12.3 — no inline MCP tool-name discovery.

Confirm red by running `/tdd`. Stop there.
```

### Prompt 2: Implement the structurer and Airtable persistence

```
Implement the (structurer + persistence) changes in `src/agent/research.ts` to make the failing tests green. Do not modify the tests.

- Colocate `ProspectSchema` and `Prospect` per §1.2.
- `structureProspect(text, companyName)` exported from the same file per §12.3 — calls `generateObject` with `ProspectSchema.omit({ domain: true, lastResearched: true })`. Use the `generateObject` prompt pinned verbatim in §12.3. Return the partial; no fallbacks, derivations, or defaults for omitted fields per §7.4.
- `researchCompany` per §12.3's outside-the-loop operations table: agent loop → structurer → caller attaches `domain` (normalized from `companyName` per §6) and `lastResearched` (`new Date().toISOString()`) → full-`ProspectSchema` validation → Airtable upsert via `upsertProspect` from `src/tools/airtable.ts`. Return shape is `{ prospect, steps }` per §12.3 — do not flatten to just `Prospect`.

Surface any PRD ambiguity rather than inventing behavior. Run `/tdd` until green.
```

### Prompt 3: Run the full pipeline end-to-end

```
Research Shopify.
```
