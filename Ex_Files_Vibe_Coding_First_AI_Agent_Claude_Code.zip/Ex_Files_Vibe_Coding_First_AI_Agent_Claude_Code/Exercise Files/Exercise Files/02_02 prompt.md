# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 2.2 — Connect Airtable tools via MCP

### Prompt 1: Provision the Airtable base

```
Provision the Airtable base from PRD §13.1, §13.2, and §13.3 — create the `Prospects` and `Outreach` tables, with field names, types, options, and primary fields exactly as written. Avoid every pitfall in §13.4(a) (Date-only vs datetime, Single Select with no preset options, `domain` not primary on `Prospects`, `subjectLine` not primary on `Outreach`). Add one demo row to `Prospects` so the base is visibly populated.

This is a one-off provisioning per §13's "not a committed setup script" rule — call the Airtable REST API directly with `fetch`. Do not add the `airtable` package as a dependency (§4.2 deny list).
```

### Prompt 2: Write the tests

```
Write the test suite for the Airtable MCP connector. Tests only — leave them red.

- Test spec: PRD §16.1 'Airtable MCP integration' — only bullets tagged (Airtable connector), including the exact-name assertion for the five pinned MCP primitives (list_tables_for_base, list_records_for_table, create_records_for_table, update_records_for_table, delete_records_for_table). Do not weaken this to a generic 'any write/delete tool' check — the exact-name canary catches MCP-side renames before they corrupt data. Skip any bullet that asserts on wrappers built in later stages (e.g. listOutreachByProspectId, createOutreach).

- Test execution contract: PRD §16.2 — observable skips, missing-env test in its own always-runs describe.

Real Airtable API, no mocks. Stop after tests are in place and confirm red.
```

### Prompt 3: Implement the MCP connector

```
Implement the Airtable MCP connector to make the tests green. Spec: PRD §12.3 — that's `getAirtableMcp` (the MCP client lifecycle helper), plus the local wrappers `upsertProspect` and `deleteProspectByDomain` (research persistence will need both shortly). All wrappers follow the §12.3 lookup-and-envelope rules: exact-name tool discovery from `client.tools()` (no fuzzy regex), structured `filters` parameter on reads, `isError` envelope unwrap on every call, `tableId` and `fldXXX` IDs resolved via `list_tables_for_base`.

Read PRD §4.2 first — it pins `@ai-sdk/mcp` to `~0.0.18` (not `^1`) and explains the Airtable hosted-MCP transport (`transport.type: 'http'`, not `'sse'`). Do not install anything; the dependency is already pinned.

Run `/tdd` when done — and confirm green.
```

### Prompt 4: List the MCP tools the server exposes

```
Open the Airtable MCP connection via getAirtableMcp and show in the chat each tool the server exposes — name and description, one tool at a time, formatted readably. Don't do anything else.
```
