# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 3.1 — Wire up the Brain

### Prompt 1: Write the seed test

```
Write the seed test for `researchCompany` per PRD §16.1's "Company research" section — only the bullets tagged **(researchCompany seed)**. Honor the stage tags strictly: do not satisfy any **(search wiring)** or **(structurer + persistence)** bullets now. Test execution contract: PRD §16.2 — env loading, observable skips, and the missing-env test in its own always-runs describe. Real Anthropic API, no mocks.

Stop after the tests are in place and confirm red by running `/tdd`. Do not implement `researchCompany` yet.
```

### Prompt 2: Implement the simplest researchCompany

```
Implement researchCompany in src/agent/research.ts to make the failing (researchCompany seed) tests green. Do not modify the tests.

Build the simplest version that satisfies the (researchCompany seed) bullets: takes a company name, calls generateText with a basic prompt, returns whatever Claude says. No tools, no system prompt, no structurer.

The (researchCompany seed) scope boundary in §16.1 explicitly forbids reaching for generateObject or importing ProspectSchema at this stage — those layer on in (structurer + persistence).

Run /tdd until green.
```

### Prompt 3: Run the Brain on a real company

```
Research Shopify — show me the raw response, don't summarize it.
```
