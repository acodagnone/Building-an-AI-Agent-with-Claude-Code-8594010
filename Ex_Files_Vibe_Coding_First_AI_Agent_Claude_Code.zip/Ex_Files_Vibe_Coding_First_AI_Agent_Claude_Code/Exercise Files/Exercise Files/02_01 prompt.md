# Vibe Code Your First AI Agent with Claude Code

**Basia Kubicka**

## Video 2.1 — Build the web search tool

### Prompt 1: Write the tests

```
Write the test suite for the `searchWeb` Tavily tool. Tests only — leave them red, do not implement `src/tools/tavily.ts` yet.

- Test spec: PRD §16.1 'Tavily web search — searchWeb' — only bullets tagged (searchWeb build). If any bullet asserts on integration with code from a later stage, skip it and surface.

- Test execution contract: PRD §16.2 — env loading via `--env-file-if-exists`, observable skips, missing-env test in its own always-runs describe.

- Tool call shape: PRD §4.2 — Vercel AI SDK v5 expects `tool.execute(input, options)`; tests calling the tool directly must pass `{ toolCallId: 'test', messages: [] }` as the second arg.

Real Tavily API, no mocks. Stop after the tests are in place and confirm red by running `/tdd`.
```

### Prompt 2: Implement the tool

```
Implement `src/tools/tavily.ts` to make the failing tests green. The tests are the spec — keep them as written and iterate the code until every test passes.

Treat PRD §16.1 (Tavily test bullets) and §4.2 (the ai@^5 tool() gotchas — inputSchema not parameters, the execute(input, options) signature, and the wide searchWeb export with the cast at the test call-site) as the source of truth for shape, file location, default recency window, result fields, blocklist placement, and library choice. The Tavily REST body must include `topic: 'news'` per the §16.1 note — without it, `published_date` is missing and the recency filter drops every result.

If anything I haven't named here is unclear, default to the PRD before guessing.

Run /tdd and confirm green.
```

### Prompt 3: Smoke-test the tool on a real company

```
Run `searchWeb` on "Datadog" via the tool. For each result show title, URL, publishedDate, and full snippet. Then rate each as a buying signal for our prospecting agent (on-target / adjacent / off-topic) and flag quality issues — query phrasing pulling in noise, blocklist gaps, oversized snippets, anything that would hurt the Brain's downstream scoring.
```
